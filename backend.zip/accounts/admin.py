from django.contrib import admin
from accounts.models import UserModel
# Register your models here.
admin.site.register(UserModel)