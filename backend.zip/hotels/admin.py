from django.contrib import admin
from .models import Hotel, Rating

# Register your models here.
admin.site.register(Hotel)
admin.site.register(Rating)


